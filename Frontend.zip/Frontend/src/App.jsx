import { useState, useEffect } from "react";

const API_URL = "https://recipe-sage-augustusyeboah6.replit.app";

function App() {
  const [agreements, setAgreements] = useState([]);
  const [newAgreement, setNewAgreement] = useState("");
  const [editing, setEditing] = useState(null);

  // Load agreements
  useEffect(() => {
    fetch(`${API_URL}/agreements`)
      .then(res => res.json())
      .then(data => setAgreements(data));
  }, []);

  // Create
  const addAgreement = async () => {
    if (!newAgreement) return;
    const res = await fetch(`${API_URL}/agreements`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: newAgreement }),
    });
    const data = await res.json();
    setAgreements([...agreements, data]);
    setNewAgreement("");
  };

  // Update
  const updateAgreement = async (id, title) => {
    const res = await fetch(`${API_URL}/agreements/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title }),
    });
    const data = await res.json();
    setAgreements(agreements.map(a => (a.id === id ? data : a)));
    setEditing(null);
  };

  // Delete
  const deleteAgreement = async (id) => {
    await fetch(`${API_URL}/agreements/${id}`, { method: "DELETE" });
    setAgreements(agreements.filter(a => a.id !== id));
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Agreement CRUD App</h1>

      <input
        value={newAgreement}
        onChange={(e) => setNewAgreement(e.target.value)}
        placeholder="Enter new agreement"
      />
      <button onClick={addAgreement}>Add</button>

      <ul>
        {agreements.map((a) => (
          <li key={a.id}>
            {editing === a.id ? (
              <>
                <input
                  defaultValue={a.title}
                  onBlur={(e) => updateAgreement(a.id, e.target.value)}
                />
                <button onClick={() => setEditing(null)}>Cancel</button>
              </>
            ) : (
              <>
                {a.title}{" "}
                <button onClick={() => setEditing(a.id)}>Edit</button>
                <button onClick={() => deleteAgreement(a.id)}>Delete</button>
              </>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;